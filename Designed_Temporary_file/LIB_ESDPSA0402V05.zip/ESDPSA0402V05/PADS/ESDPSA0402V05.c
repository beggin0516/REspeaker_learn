*PADS-LIBRARY-SCH-DECALS-V9*

ESDPSA0402V05       32000 32000 100 10 100 10 4 5 0 2 8
TIMESTAMP 2022.09.08.12.51.47
"Default Font"
"Default Font"
600   350   0 0 100 10 "Default Font"
REF-DES
600   250   0 0 100 10 "Default Font"
PART-TYPE
600   -200  0 0 100 10 "Default Font"
*
600   -300  0 0 100 10 "Default Font"
*
CLOSED 4 10 0 -1
400   0    
200   -100 
200   100  
400   0    
CLOSED 4 10 0 -1
400   0    
600   -100 
600   100  
400   0    
OPEN   2 10 0 -1
400   -180 
400   180  
OPEN   2 10 0 -1
440   200  
400   180  
OPEN   2 10 0 -1
400   -180 
360   -200 
T0     0     0 0 0     20    0 0 0     -20   0 32 PIN
P-520  0     0 2 -80   0     0 2 0
T800   0     0 2 0     20    0 0 0     -20   0 32 PIN
P-520  0     0 2 -80   0     0 2 0


*END*